<?php
include 'classes/contatos.class.php';
$contato = new Contatos();

if(!empty ($_POST['idContato'])){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $cidade = $_POST['cidade'];
    $rua = $_POST['rua'];
    $bairro = $_POST['bairro'];
    $numero = $_POST['numero'];
    $cep = $_POST['cep'];
    $profissao = $_POST['profissao'];
    $foto = $_POST['foto'];
    $dt_nasc = $_POST['dt_nasc'];
    $idContato = $_POST['idContato'];
    
    if(!empty($email)){
        $contato->editar($nome, $email, $telefone, $cidade, $rua, $numero, $bairro, $cep, $profissao, $foto, $dt_nasc, $idContato);
    }
    header("Location: /AgendaSenac");
}

?>