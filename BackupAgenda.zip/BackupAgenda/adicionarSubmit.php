<?php
    include 'inc/header.inc.php';
?>

<h1 class="text-center">ADICIONAR</h1>

<div class="row justify-content-center">
    <form method="POST" action="adicionarContatoSubmit.php" class="d-fluid c">
        Nome: <br>
        <input type="text" name="nome" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Email: <br>
        <input type="text" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Telefone: <br>
        <input type="text" name="telefone" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Cidade: <br>
        <input type="text" name="cidade" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Rua: <br>
        <input type="text" name="rua" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Bairro: <br>
        <input type="text" name="bairro" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Numero: <br>
        <input type="text" name="numero" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        CEP: <br>
        <input type="text" name="cep" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Profissao: <br>
        <input type="text" name="profissao" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Foto: <br>
        <input type="text" name="foto" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Data Nasc: <br>
        <input type="date" name="dt_nasc" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
    
        <input type="submit" name="btCadastrar" class="btn btn-success" value="ADICIONAR" />
 
    </form>
</div>

<?php
    include 'inc/footer.inc.php';
?>