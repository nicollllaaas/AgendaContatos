<?php
require_once 'classes/conexao.class.php';
$con = new Connect();
$con->conectar();