<?php
    include 'inc/header.inc.php';
    include 'classes/usuarios.class.php';

    session_start();
if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}
?>

<h1 class="text-center">ADICIONAR</h1>

<div class="row justify-content-center">
    <form method="POST" action="adicionarUsuarioSubmit.php" class="d-fluid c">
        Nome: <br>
        <input type="text" name="nome" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Email: <br>
        <input type="text" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Senha: <br>
        <input type="password" name="senha" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Permissões: <br>
        <label for="add">
            <input type="checkbox" id="add" name="permissoes[]" value="add"> Adicionar
        </label>    
        <label for="edit">
            <input class="ml-3" id="edit" type="checkbox" name="permissoes[]" value="edit"> Editar
        </label>
        <label for="del">
            <input class="ml-3" id="del" type="checkbox" name="permissoes[]" value="del"> Deletar
        </label>
        <label for="super">
            <input class="ml-3" id="super" type="checkbox" name="permissoes[]" value="super"> Super 
        </label><br><br>

        <input type="submit" name="btCadastrar" class="btn btn-success" value="ADICIONAR" />
 
    </form>
</div>

<?php
    include 'inc/footer.inc.php';
?>