       
    <footer class="fluid-container bg-dark">
        <!--<ul class="container ">
            <li class="social"><a href="facebook.com" class="social"> Facebook</a></li>
            <li class="social"><a href="x.com" class="social"> X</a> </li>
            <li class="social"><a href="instagram.com" class="social">Instagram</a></li>
        </ul>-->
        
        <hr>
        <h4 class="text-light">&copy; Todos os direitos reservados </h4>

        </footer>

        <script type="text/javascript" src="js/jquery-3.7.1.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"> </script>
        
    </body>
    </html>