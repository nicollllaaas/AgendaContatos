<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="css/bootstrap.min.css">
    <link href="inc/style.css">
    <title>Agenda</title>
</head>
<body>
<div class="fluid-container ">
    <header>
        <div class=" navbar navbar-dark bg-dark">
            <div class = "container d-flex  justify-content-between">
                <a href="index.php" class=" navbar-brand" style="font-size: 250%">
                <img src="img/caderno.png" alt="" style="width: 12%; position: relative;">
                   Agenda Senac 
                </a>
            <link rel = "stylesheet" type = "text/css" href = "css/style.css">
                

        
                </nav>
            </div> 
        </div>
       
    </header>
</div>
