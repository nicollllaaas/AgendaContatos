
<?php
    include 'inc/header.inc.php';   
    include 'classes/contatos.class.php';
    $contato = new Contatos();
 
    if(!empty($_GET['idContato'])){
        $idContato = $_GET['idContato'];
        $info = $contato->buscar($idContato);
        if(empty($info['email'])){
            header("Location: /AgendaSenac");
            exit;
        }
   
    }else{
        header("Location: /AgendaSenac");
        exit;
    }
 
?>

<h1 class="text-center">EDITAR CONTATO</h1>
<div class="row justify-content-center">
    <form method="POST" action="editarContatoSubmit.php">
        <input type="hidden" name="idContato"  class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"value="<?php echo $info['idContato']?>"/>
        Nome: <br>
        <input type="text" name="nome" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['nome']?>"/><br><br>
        Email: <br>
        <input type="text" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['email']?>"/><br><br>
        Telefone: <br>
        <input type="text" name="telefone" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['telefone']?>"/><br><br>
        Cidade: <br>
        <input type="text" name="cidade" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['cidade']?>"/><br><br>
        Rua: <br>
        <input type="text" name="rua" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['rua']?>"/><br><br>
        Bairro: <br>
        <input type="text" name="bairro" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['bairro']?>"/><br><br>
        Número: <br>
        <input type="text" name="numero" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['numero']?>"/><br><br>
        CEP: <br>
        <input type="text" name="cep" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['cep']?>"/><br><br>
        Profissâo: <br>
        <input type="text" name="profissao" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['profissao']?>"/><br><br>
        Foto: <br>
        <input type="text" name="foto" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['foto']?>"/><br><br>
        Data Nasc: <br>
        <input type="date" name="dt_nasc" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['dt_nasc']?>"/><br><br>

        <input type="submit" class="btn btn-success" name="btCadastrar" value="Alterar"/>
    </form>
</div>

<?php
    include 'inc/footer.inc.php';
?>