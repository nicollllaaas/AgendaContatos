<?php
include 'classes/contatos.class.php';
$contato = new Contatos();

if(!empty($_POST['email'])){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $cidade = $_POST['cidade'];
    $rua = $_POST['rua'];
    $bairro = $_POST['bairro'];
    $numero = $_POST['numero'];
    $cep = $_POST['cep'];
    $profissao = $_POST['profissao'];
    $foto = $_POST['foto'];
    $dt_nasc = $_POST['dt_nasc'];
 
    $contato->adicionar($email, $nome, $telefone, $cidade, $rua, $bairro, $numero, $cep, $profissao, $foto, $dt_nasc);

    header('Location:index.php');
}
else{
    echo '<script type="text/javascript">alert("Email já cadastrado!");</script>';
}

?>